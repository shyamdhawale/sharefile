const mongoose = require("mongoose");

const MOGOURI = "mongodb://www.foxtechno.com:57007/tranterDb";

const initializeMogoServer = async () =>{
    try{
        await mongoose.connect(MOGOURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,          
            

        });
        console.log("Connnected to DB!!");
    }
    catch (e) {
        console.log(e);
        throw e;
    }
};

module.exports = initializeMogoServer;