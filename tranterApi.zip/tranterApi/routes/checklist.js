const express = require("express");
const Checklist = require("../models/checklist");
const router = express.Router();


// router
router.route('/')
.get((req, res) =>{
    Checklist.find((err, data) =>{
        if(err){
            return res.json({error: err});
        }
        res.json({Checklist: data});    
    })
})
.post((req, res)=>{
    // console.log(req.body)
    const body = req.body;
    const characteristicsMain = req.body.characteristicsmain;
    // console.log(abc.length);
    
    // abc.map(a => console.log(a));
    const newCharacteristicsmain = [];
    newCharacteristicsmain.push(characteristicsMain);
    console.log(newCharacteristicsmain[0]);
    const newChecklist = new Checklist({
        logo:body.logo,
        reportname:body.reportname,
        reportno:body.reportno,
        date:body.date,
        supplier:body.supplier,
        vendorcode:body.vendorcode,
        classificationmain:body.classificationmain,
        customer:body.customer,
        critical:body.critical,
        major:body.major,
        minor:body.minor,
        partname:body.partname,
        partno:body.partno,
        mfgsrno:body.mfgsrno,
        drgno:body.drgno,
        characteristicsmain: newCharacteristicsmain[0],        
    });
    newChecklist.save((err) =>{
        if(err){
            return res.json({error: err});
        }
        res.json({info: "Checklist created successfully!"})
    })

    // res.end()
});

// route per node
router.route('/:id')
    .get((req, res) =>{
        console.log(req.params.id)
        Checklist.find({classificationmain: req.params.id}, (err, data) =>{
            if (err){
                return res.json({ error: err})
            }
            res.json(data)
        })
        // Checklist.findById(req.params.id, (err, data) =>{
        //     if (err){
        //         return res.json({ error: err})
        //     }
        //     res.json(data)
        // })
        // res.json({ info: "no data"})
        // res.end()
    })
    .patch((req, res) =>{
        // console.log(req.body)
        Checklist.updateOne(
            { _id: req.params.id},
            { $set: req.body},
            (err) =>{
                if (err) {
                    return res.json({ error: err})
                }
                return res.json({ info: "update successfully."})
            }
            )
    })
    .delete((req, res) =>{
        Checklist.deleteOne(
            {_id: req.params.id }, 
        (err) => {
            if (err) {return res.json({error: err})}
            return res.json({ info: 'Deleted successfully!'})
    })
    })

module.exports = router;