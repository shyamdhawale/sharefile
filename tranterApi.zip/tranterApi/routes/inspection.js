const express = require("express");

const router = express.Router();
const Inpsection = require("../models/inspection");

// router
router
  .route("/")
  .get((req, res) => {
    Inpsection.find((err, data) => {
      if (err) {
        return res.json({ message: "no record found!" });
      }
      return res.json(data);
    });
  })
  .post((req, res) => {
    // console.log(req.body.data);
    const data = req.body.data;
    // console.log(inspectionData);
    const newInspection = new Inpsection({
      client: data.client,
      pono: data.pono,
      serialnumber: data.serialnumber,
      date: data.date,
      model: data.model,
      mfgsrno: data.mfgsrno,
      tagnumber: data.tagnumber,
      qapnumber: data.qapnumber,
      drgnumber: data.drgnumber,
      materialmoc_1: data.materialmoc_1,
      materialheatno_1: data.materialheatno_1,
      materialmtcno_1: data.materialmtcno_1,
      materialmoc_2: data.materialmoc_2,
      materialheatno_2: data.materialheatno_2,
      materialmtcno_2: data.materialmtcno_2,
      materialmoc_3: data.materialmoc_3,
      materialheatno_3: data.materialheatno_3,
      materialmtcno_3: data.materialmtcno_3,
      materialmoc_4: data.materialmoc_4,
      materialheatno_4: data.materialheatno_4,
      materialmtcno_4: data.materialmtcno_4,
      materialmoc_5: data.materialmoc_5,
      materialheatno_5: data.materialheatno_5,
      materialmtcno_5: data.materialmtcno_5,
      materialmoc_6: data.materialmoc_6,
      materialheatno_6: data.materialheatno_6,
      materialmtcno_6: data.materialmtcno_6,
      dimentionobserved_1: data.dimentionobserved_1,
      dimentionreq_1: data.dimentionreq_1,
      dimentionobserved_2: data.dimentionobserved_2,
      dimentionreq_2: data.dimentionreq_2,
      dimentionobserved_3: data.dimentionobserved_3,
      dimentionreq_3: data.dimentionreq_3,
      dimentionobserved_4: data.dimentionobserved_4,
      dimentionreq_4: data.dimentionreq_4,
      dimentionobserved_5: data.dimentionobserved_5,
      dimentionreq_5: data.dimentionreq_5,
      dimentionobserved_6: data.dimentionobserved_6,
      dimentionreq_6: data.dimentionreq_6,
      dimentionobserved_7: data.dimentionobserved_7,
      dimentionreq_7: data.dimentionreq_7,
      dimentionobserved_8: data.dimentionobserved_8,
      dimentionreq_8: data.dimentionreq_8,
      dimentionobserved_9: data.dimentionobserved_9,
      dimentionreq_9: data.dimentionreq_9,
      dimentionobserved_10: data.dimentionobserved_10,
      dimentionreq_10: data.dimentionreq_10,
      dimentionobserved_11: data.dimentionobserved_11,
      dimentionreq_11: data.dimentionreq_11,
      hyrodprocedureno: data.hyrodprocedureno,
      hydrotestpressurereqd: data.hydrotestpressurereqd,
      hydropressureguageno: data.hydropressureguageno,
      hydrocertificateno: data.hydrocertificateno,
      hydropressurehotside: data.hydropressurehotside,
      hydroobspressue_1: data.hydroobspressue_1,
      hydropressurecoldside: data.hydropressurecoldside,
      hydroobspressue_2: data.hydroobspressue_2,
      hydroduration: data.hydroduration,
      hydroduration_obs: data.hydroduration_obs,
      hydroresult: data.hydroresult,
      hydrodaccepted: data.hydrodaccepted,
      paitingprimer_1: data.paitingprimer_1,
      paintingfinalpre_1: data.paintingfinalpre_1,
      paintingdft_1: data.paintingdft_1,
      paitingprimer_2: data.paitingprimer_2,
      paintingfinalpre_2: data.paintingfinalpre_2,
      paintingdft_2: data.paintingdft_2,
    });

    newInspection.save((err) => {
      if (err) {
        return res.json({ message: err });
      }
      return res.json({ message: "Report Saved Successfully!" });
    });
  });
// router route
router
  .route("/:id")
  .get((req, res) => {
    Inpsection.findById({ _id: req.params.id }, (err, data) => {
      if (err) {
        return res.json({ message: "Report not found!" });
      }
      res.json({ data: data });
    });
  })
  .patch((req, res) => {
    // console.log(req.body)
    Inpsection.updateOne({ _id: req.params.id }, { $set: req.body }, (err) => {
      if (err) {
        return res.json({ error: err });
      }
      return res.json({ message: "Update successfully." });
    });
  })
  .delete((req, res) => {
    Inpsection.deleteOne({ _id: req.params.id }, (err) => {
      if (err) {
        return res.json({ error: err });
      }
      return res.json({ message: "Deleted successfully!" });
    });
  });

module.exports = router;
