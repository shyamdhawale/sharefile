const express = require("express");

const router = express.Router();

// router
router.route("/").get((req, res) => {
  console.log(req);
  res.end();
}).post((req, res) =>{
    console.log(req);
    res.end()
})

module.exports = router;
