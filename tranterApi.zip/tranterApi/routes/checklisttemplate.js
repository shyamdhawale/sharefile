const express = require("express");
const template = require("../models/checklistMaster");
const router = express.Router();

// router
router.route('/')
.get((req, res) =>{
    template.find((err, data) =>{
        if(err){
            return res.json({error: err});
        }
        res.json({template: data});    
    })
})
.post((req, res)=>{
    console.log(req.body)
    const body = req.body;
    const characteristicsMain = req.body.characteristicsmain;
    const bodyRemarks = req.body.remarks;

    // console.log(abc.length);
    
    // abc.map(a => console.log(a));
    const newCharacteristicsmain = [];
    const newRemarks = [];
    newRemarks.push(bodyRemarks);
    newCharacteristicsmain.push(characteristicsMain);
    // console.log(newCharacteristicsmain[0]);
    const newTemplate = new template({
        logo:body.logo,
        reportname:body.reportname,
        reportno:body.reportno,
        date:body.date,
        supplier:body.supplier,
        vendorcode:body.vendorcode,
        classificationmain:body.classificationmain,
        customer:body.customer,
        critical:body.critical,
        major:body.major,
        minor:body.minor,
        partname:body.partname,
        partno:body.partno,
        mfgsrno:body.mfgsrno,
        drgno:body.drgno,
        characteristicsmain: newCharacteristicsmain[0],
        remarks: newRemarks[0]  
    });
    newTemplate.save((err) =>{
        if(err){
            return res.json({error: err});
        }
        res.json({info: "Template created successfully!"})
    })
    // res.end()
});

// route per node
router.route('/:id')
    .get((req, res) =>{

        // console.log(req.params.id)
        template.find({classificationmain: req.params.id}, (err, data) =>{
            if (err){
                return res.json({ error: err})
            }
            res.json(data)
        })
        // template.findById(req.params.id, (err, data) =>{
        //     if (err){
        //         return res.json({ error: err})
        //     }
        //     res.json(data)
        // })
        // res.json({ info: "no data"})
        // res.end()
    })
    .patch((req, res) =>{
        // console.log(req.body)
        template.updateOne(
            { _id: req.params.id},
            { $set: req.body},
            (err) =>{
                if (err) {
                    return res.json({ error: err})
                }
                return res.json({ INFO: "Update successfully."})
            }
            )
    })
    .delete((req, res) =>{
        template.deleteOne(
            {_id: req.params.id }, 
        (err) => {
            if (err) {return res.json({error: err})}
            return res.json({ INFO: 'Deleted successfully!'})
    })
    })

module.exports = router;