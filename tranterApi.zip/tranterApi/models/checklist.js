const mongoose = require('mongoose');

const ChecklistSchema = mongoose.Schema({
    logo:String,
    reportname:String,
    reportno:String,
    date:String,
    supplier:String,
    vendorcode:String,
    classificationmain:String,
    customer:String,
    critical:String,
    major:String,
    minor:String,
    partname:String,
    partno:String,
    mfgsrno:String,
    drgno:String,
    characteristicsmain: [],
    remarks:[],
    createAt: {
        type: Date,
        default: Date.now()
    }
});

module.exports = mongoose.model('checklist',ChecklistSchema);