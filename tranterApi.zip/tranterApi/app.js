const express = require("express");
const cors = require('cors');

const bodyParser = require("body-parser");
const initializeMogoServer = require("./config/db");

// initialize 
const app = express();

// initialize mongodb
initializeMogoServer();

// Middleware
app.use(cors());
// app.use(express.json());
// app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json({type: 'application/json'}));
// 
app.get('/', (req, res) => {
    res.send("hello")
});

app.use('/api/master/checklist', require('./routes/checklisttemplate'));
// app.use('/api/master/inspection', require('./routes/'));
app.use('/api/checklist', require('./routes/checklist'));
app.use('/inspection', require('./routes/inspection'));

app.listen(3001, ()=>{
    console.log('Server started on port 3001')
});